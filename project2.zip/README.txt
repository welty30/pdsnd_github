https://www.geeksforgeeks.org/sort-dataframe-according-to-row-frequency-in-pandas/#
Very helpful with groupby(), sorting DataFrame for the station routes

https://www.geeksforgeeks.org/__init__-in-python/
Refresher with class basics
